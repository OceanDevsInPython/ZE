import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
import os
import sys

class PythonEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("ZE Custom Python Compiler")
        self.root.geometry("1000x600")

        self.current_folder = None
        self.file_path = None  # Store the currently opened file path

        # Modern styling for the UI
        self.style = ttk.Style()
        self.style.configure("TButton", font=("Helvetica", 12), padding=10)
        self.style.configure("TTreeview", font=("Helvetica", 12), rowheight=25)
        self.style.configure("TTreeview.Heading", font=("Helvetica", 14, 'bold'))

        # Frame for left-side file explorer and right-side editor
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(expand=True, fill=tk.BOTH)

        # File Explorer (Left)
        self.explorer_frame = tk.Frame(self.main_frame, width=250)
        self.explorer_frame.pack(side=tk.LEFT, fill=tk.Y)

        self.tree = ttk.Treeview(self.explorer_frame, show="tree")
        self.tree.pack(expand=True, fill=tk.BOTH)

        self.tree.bind("<Double-1>", self.open_file_from_tree)

        # Scrollbar for the file explorer
        self.tree_scroll = tk.Scrollbar(self.explorer_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=self.tree_scroll.set)
        self.tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Code Editor with Scrollbar
        self.editor_frame = tk.Frame(self.main_frame)
        self.editor_frame.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)

        # Line Number Display
        self.line_numbers = tk.Text(self.editor_frame, width=4, padx=5, takefocus=0, border=0, background="#ddd",
                                    state="disabled", font=("Courier", 12))
        self.line_numbers.pack(side=tk.LEFT, fill=tk.Y)

        # Text Widget with Scrollbar
        self.text_scroll = tk.Scrollbar(self.editor_frame, orient=tk.VERTICAL)
        self.text_widget = tk.Text(self.editor_frame, wrap=tk.WORD, undo=True, font=("Courier", 12),
                                   yscrollcommand=self.text_scroll.set)
        self.text_scroll.config(command=self.text_widget.yview)
        self.text_widget.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)
        self.text_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Link scrolling between text and line numbers
        self.text_widget.bind("<KeyRelease>", self.update_line_numbers)
        self.text_widget.bind("<MouseWheel>", self.scroll_both)

        # Buttons
        self.button_frame = tk.Frame(self.root)
        self.button_frame.pack(fill=tk.X)

        self.clear_button = ttk.Button(self.button_frame, text="Clear", command=self.clear_text)
        self.clear_button.pack(side=tk.LEFT, padx=10, pady=10)

        self.explorer_button = ttk.Button(self.button_frame, text="Explore Files", command=self.open_folder)
        self.explorer_button.pack(side=tk.LEFT, padx=10, pady=10)

        self.save_button = ttk.Button(self.button_frame, text="Save", command=self.save_file)
        self.save_button.pack(side=tk.LEFT, padx=10, pady=10)

        self.save_as_button = ttk.Button(self.button_frame, text="Save As", command=self.save_file_as)
        self.save_as_button.pack(side=tk.LEFT, padx=10, pady=10)

        self.run_button = ttk.Button(self.button_frame, text="Run", command=self.run_script)
        self.run_button.pack(side=tk.LEFT, padx=10, pady=10)

    def scroll_both(self, event):
        """Scroll text and line numbers together."""
        self.text_widget.yview_scroll(-1 * (event.delta // 120), "units")
        self.line_numbers.yview_scroll(-1 * (event.delta // 120), "units")
        return "break"

    def update_line_numbers(self, event=None):
        """Update line numbers based on text content."""
        self.line_numbers.config(state="normal")
        self.line_numbers.delete(1.0, tk.END)

        line_count = self.text_widget.index("end-1c").split(".")[0]
        line_numbers = "\n".join(str(i) for i in range(1, int(line_count) + 1))
        self.line_numbers.insert(tk.END, line_numbers)

        self.line_numbers.config(state="disabled")

    def open_folder(self):
        """Open a folder and populate the Treeview with its contents."""
        folder_path = filedialog.askdirectory()
        if folder_path:
            self.current_folder = folder_path
            self.tree.delete(*self.tree.get_children())
            self.populate_tree(folder_path)

    def populate_tree(self, folder_path):
        """Populate the Treeview with the folder structure."""
        root_node = self.tree.insert('', 'end', text=folder_path, open=True)
        for item in os.listdir(folder_path):
            item_path = os.path.join(folder_path, item)
            if os.path.isdir(item_path):
                self.tree.insert(root_node, 'end', text=item, open=False)
            else:
                self.tree.insert(root_node, 'end', text=item)

    def open_file_from_tree(self, event):
        """Open the selected .py file when double-clicked in the tree view."""
        selected_item = self.tree.selection()
        if selected_item:
            file_name = self.tree.item(selected_item)["text"]
            file_path = os.path.join(self.current_folder, file_name)

            if os.path.isfile(file_path) and file_path.endswith(".py"):
                with open(file_path, 'r') as file:
                    code = file.read()
                    self.text_widget.delete(1.0, tk.END)
                    self.text_widget.insert(tk.END, code)
                    self.file_path = file_path
                    self.update_line_numbers()

    def save_file(self):
        """Save the current content to the file."""
        if self.file_path:
            with open(self.file_path, 'w') as file:
                code = self.text_widget.get("1.0", tk.END)
                file.write(code)
            messagebox.showinfo("Success", "File saved successfully!")
        else:
            messagebox.showerror("Error", "No file is currently open.")

    def save_file_as(self):
        """Save the current content to a new file."""
        file_path = filedialog.asksaveasfilename(defaultextension=".py", filetypes=[("Python Files", "*.py")])
        if file_path:
            with open(file_path, 'w') as file:
                code = self.text_widget.get("1.0", tk.END)
                file.write(code)
            self.file_path = file_path
            messagebox.showinfo("Success", "File saved successfully!")

    def run_script(self):
        """Run the currently open Python script in a new terminal window."""
        if self.file_path:
            try:
                if sys.platform.startswith('win'):
                    os.system(f'start cmd /k "python \"{self.file_path}\""')
                elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):
                    os.system(f'gnome-terminal -- bash -c "python3 \\"{self.file_path}\\"; exec bash"')
            except Exception as e:
                messagebox.showerror("Error", f"Could not run the script: {e}")
        else:
            messagebox.showerror("Error", "No file is open. Save or open a file before running.")

    def clear_text(self):
        """Clear the text area."""
        self.text_widget.delete(1.0, tk.END)
        self.file_path = None
        self.update_line_numbers()

if __name__ == "__main__":
    root = tk.Tk()
    editor = PythonEditor(root)
    root.mainloop()
